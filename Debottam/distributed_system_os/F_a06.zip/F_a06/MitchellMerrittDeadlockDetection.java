import java.util.*;

public class MitchellMerrittDeadlockDetection {

    private final Map<String, List<String>> waitForGraph;

    public MitchellMerrittDeadlockDetection() {
        waitForGraph = new HashMap<>();
    }

    public void addWait(String processA, String processB) {
        System.out.printf(" Adding wait: %s → %s%n", processA, processB);
        waitForGraph.putIfAbsent(processA, new ArrayList<>());
        waitForGraph.get(processA).add(processB);
    }

    public void removeWait(String processA, String processB) {
        System.out.printf(" Removing wait: %s → %s%n", processA, processB);
        List<String> waits = waitForGraph.get(processA);
        if (waits != null) {
            waits.remove(processB);
            if (waits.isEmpty()) {
                waitForGraph.remove(processA);
            }
        }
    }

    public boolean detectDeadlock() {
        System.out.println(" Starting deadlock detection...");
        Set<String> visited = new HashSet<>();
        Set<String> recStack = new HashSet<>();

        for (String process : waitForGraph.keySet()) {
            if (detectCycleDFS(process, visited, recStack)) {
                System.out.printf(" Deadlock cycle detected involving: %s%n", process);
                return true;
            }
        }

        System.out.println("No deadlock detected.");
        return false;
    }

    private boolean detectCycleDFS(String current, Set<String> visited, Set<String> recStack) {
        System.out.printf(" Visiting process: %s%n", current);

        if (recStack.contains(current)) {
            System.out.printf(" Back edge found to %s — cycle exists!%n", current);
            return true;
        }

        if (visited.contains(current)) {
            System.out.printf(" Already visited %s — skipping.%n", current);
            return false;
        }

        visited.add(current);
        recStack.add(current);

        List<String> neighbors = waitForGraph.getOrDefault(current, new ArrayList<>());
        for (String neighbor : neighbors) {
            System.out.printf("  ↳ %s is waiting on %s%n", current, neighbor);
            if (detectCycleDFS(neighbor, visited, recStack)) {
                return true;
            }
        }

        recStack.remove(current);
        return false;
    }

    public static void main(String[] args) {
        MitchellMerrittDeadlockDetection detector = new MitchellMerrittDeadlockDetection();

        // Scenario 1: Deadlock
        detector.addWait("P1", "P2");
        detector.addWait("P2", "P3");
        detector.addWait("P3", "P1");

        boolean result1 = detector.detectDeadlock();
        System.out.println("Result: " + (result1 ? " Deadlock Detected!" : "No Deadlock") + "\n");

        // Remove one edge to break the cycle
        detector.removeWait("P3", "P1");

        // Scenario 2: No deadlock
        boolean result2 = detector.detectDeadlock();
        System.out.println("Result: " + (result2 ? " Deadlock Detected!" : "No Deadlock"));
    }
}

